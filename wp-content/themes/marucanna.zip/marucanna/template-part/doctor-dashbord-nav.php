<div class="dashboard_nav text-end mb-5">
    <a href="<?php echo home_url('doctor-dashboard'); ?>" class="btn style_4 small mr-1">Dashbord</a>
    <a href="<?php echo wp_logout_url( home_url('login') ); ?>" class="btn btn-danger small">Logout</a>
</div>
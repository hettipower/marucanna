jQuery(document).ready(function ($) {
    our_team_slider();
    sticky_header();
});